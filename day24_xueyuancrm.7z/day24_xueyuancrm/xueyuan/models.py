#coding: utf-8
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from django.contrib.auth.models import User
class Teacher(models.Model):
    #等下留意一下这个问题
    user = models.OneToOneField(User)
    name = models.CharField(u"姓名",max_length=32)
    def __unicode__(self):
        return self.name
    class Meta:
        verbose_name = u'老师'
        verbose_name_plural = u'老师'

class StudentInfo(models.Model):
    qq = models.CharField(u"QQ号",max_length=64,unique=True)
    name = models.CharField(u"姓名",max_length=32,blank=True,null=True)
    phone = models.CharField(u'手机号',blank=True,null=True,max_length=32)
    stu_id = models.CharField(u"学号",blank=True,null=True,max_length=32)
    def __unicode__(self):
        return "%s--%s" % (self.name,self.stu_id)
    class Meta:
        verbose_name = u'学员信息'
        verbose_name_plural = u'学员信息'

class Course(models.Model):
    name = models.CharField(u'课程名称',max_length=128,unique=True)
    brief = models.TextField(u"课程简介")
    def __unicode__(self):
        return self.name
    class Meta:
        verbose_name = u'课程表'
        verbose_name_plural = u'课程表'

class Classlist(models.Model):
    course = models.ForeignKey(Course)
    semester = models.CharField(u"学期", max_length=32)
    teachers = models.ManyToManyField(Teacher, verbose_name=u"讲师")
    def __unicode__(self):
        return "%s(%s)" %(self.course,self.semester)
    class Meta:
        verbose_name = u'班级表'
        verbose_name_plural = u'班级表'
        unique_together = ("course", "semester")

class CourseRecord(models.Model):
    course = models.ForeignKey(Classlist,verbose_name="班级(课程)",default=1)
    day_num = models.IntegerField(u'节次',help_text=u"这里填写这是第几天的课程,必须为数字")
    date = models.DateField(auto_now_add=True,verbose_name=u"记录添加时间")
    teacher = models.ForeignKey(Teacher,verbose_name=u"讲师")
    def __unicode__(self):
        return "%s,第%s天 老师: %s" %(self.course,self.day_num,self.teacher)
    class Meta:
        verbose_name = u'课堂表'
        verbose_name_plural = u'课堂表'
        unique_together = ("course", "day_num")

class StudyRecord(models.Model):
    course_record = models.ForeignKey(CourseRecord,verbose_name=u"第几天的课程")
    student = models.ForeignKey(StudentInfo,verbose_name=u"学员")
    record_choices = (('checkout',u"已签到"),
                      ('late',u"迟到"),
                      ('noshow',u"缺勤"),
                      ('leave_early',u"早退"),
                      )
    record = models.CharField(u'上课记录',choices=record_choices,default="checkout",max_length=64)
    date = models.DateTimeField(auto_now_add=True)
    note = models.CharField(u"备注",max_length=128,blank=True,null=True)
    def colored_record(self):
        color_dic = {
            'checkout': "#16e01e",
            'late': "#f1e110",
            'noshow': "#f90a0a",
            'leave_early': "#636061",
        }
        html_td = '<span style="padding:5px;background-color:%s;">%s</span>' % (color_dic[self.record], self.get_record_display())
        return html_td

    colored_record.allow_tags = True
    course_record.short_description = "签到成绩"
    class Meta:
        verbose_name = u'上课记录'
        verbose_name_plural = u'上课记录'
        unique_together = ("course_record", "student")
    def __unicode__(self):
        if self.record == 'checkout':
            self.record = '已签到'
        elif self.record == 'late':
            self.record = '迟到'
        elif self.record == 'noshow':
            self.record = '缺勤'
        elif self.record == 'leave_early':
            self.record = '早退'
        return u"%s,学员: %s,记录: %s,备注: %s " % (self.course_record,self.student,self.record,self.note)
