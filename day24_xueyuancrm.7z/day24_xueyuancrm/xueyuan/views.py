#coding: utf-8
from django.shortcuts import render,render_to_response,HttpResponse

# Create your views here.
from xueyuan import models
def index(request):
    if request.method == 'POST':
        stuid = request.POST['stuid']
        print stuid
        aaa = models.StudentInfo.objects.filter(stu_id__contains=stuid)
        print aaa
        if aaa:
            studentid = int(aaa[0].id)
            print studentid
            info = models.StudyRecord.objects.filter(student_id=studentid)
            print info[0]
            name = info[0].student.name
            for i in info:
                if i.record == ''
            return render_to_response('list.html', {"studentinfo": info, "studentname": name})
        else:
            return HttpResponse("你输出的学号不存在")

    else:
        return render(request,"index.html")