#coding: utf-8
from django.contrib import admin

# Register your models here.
from xueyuan import models

class StudyRecordAdmin(admin.ModelAdmin):
    list_display = ('course_record','get_stu_name','get_stu_id','colored_record','date','note')
    list_filter = ("course_record__course__course","record","course_record__course")
    search_fields = ('student__name','student__stu_id')
    actions = ["set_to_checkout","set_to_late","set_to_noshow","set_to_leave_early"]

    def set_to_checkout(modeladmin, request, queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        models.StudyRecord.objects.filter(id__in=selected).update(record="checkout")
    def set_to_late(modeladmin, request, queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        models.StudyRecord.objects.filter(id__in=selected).update(record="late")
    def set_to_noshow(modeladmin, request, queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        models.StudyRecord.objects.filter(id__in=selected).update(record="noshow")
    def set_to_leave_early(modeladmin, request, queryset):
        selected = request.POST.getlist(admin.ACTION_CHECKBOX_NAME)
        models.StudyRecord.objects.filter(id__in=selected).update(record="leave_early")


    def get_stu_id(self,obj):
        return obj.student.stu_id
    def get_stu_name(self,obj):
        return obj.student.name

    get_stu_id.short_description = u"学员"
    get_stu_name.short_description = u"学员名字"
    set_to_checkout.short_description = u"设置选中的学员为已签到"
    set_to_late.short_description = u"设置选中的学员为迟到"
    set_to_noshow.short_description = u"设置选中的学员为缺勤"
    set_to_leave_early.short_description = u"设置选中的学员为早退"

admin.site.register(models.Teacher)
admin.site.register(models.StudentInfo)
admin.site.register(models.Course)
admin.site.register(models.Classlist)
admin.site.register(models.CourseRecord)
admin.site.register(models.StudyRecord,StudyRecordAdmin)